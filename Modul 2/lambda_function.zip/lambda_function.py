import json
import base64
import datetime

def lambda_handler(event, context):
    output_records = []  # Pindahkan ke dalam fungsi
    
    for record in event["records"]:
        try:
            # Decode base64 dan parse JSON
            payload = base64.b64decode(record["data"]).decode("utf-8")
            json_data = json.loads(payload)
            
            # Enrich data
            json_data["processedAt"] = datetime.datetime.now().isoformat(sep=" ", timespec="seconds")
            
            # Encode kembali ke base64
            json_string = json.dumps(json_data)
            b64_encoded_data = base64.b64encode(json_string.encode("utf-8")).decode("utf-8")
            
            # Tambahkan ke output
            output_records.append({
                "recordId": record["recordId"],
                "result": "Ok",
                "data": b64_encoded_data
            })
            
        except Exception as e:
            # Jika error, kembalikan data asli dengan status failed
            output_records.append({
                "recordId": record["recordId"],
                "result": "ProcessingFailed",
                "data": record["data"]  # Data asli (tanpa decode)
            })
    
    return {"records": output_records}